# TowerLab

A tower defense game in Java Swing. See the [README](../README.md) for the full overview, class structure and how to run it.

## Quick start

```bash
# Mac / Linux
javac *.java
java TowerLab
```

On Windows Command Prompt list the files instead of `*.java` (see the README).
